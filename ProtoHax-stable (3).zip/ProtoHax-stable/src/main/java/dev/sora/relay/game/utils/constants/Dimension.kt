package dev.sora.relay.game.utils.constants

object Dimension {

    const val OVERWORLD = 0
    const val NETHER = 1
    const val THE_END = 2
}